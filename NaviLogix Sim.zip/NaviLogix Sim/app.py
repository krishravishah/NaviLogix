from flask import Flask, render_template, request, jsonify
from flask_mail import Mail, Message
import pandas as pd

app = Flask(__name__)

# ---------- Mail Config ----------
app.config['MAIL_SERVER'] = 'smtp.gmail.com'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USERNAME'] = 'your_email@gmail.com'
app.config['MAIL_PASSWORD'] = 'your_app_password'

mail = Mail(app)

# ---------- Load Vehicle Data ----------
try:
    vehicle_df = pd.read_csv('vehicles.csv')
except FileNotFoundError:
    vehicle_df = pd.DataFrame(columns=["VehicleNo", "Driver", "Status", "Speed", "LastUpdate"])

# ---------- Home Route ----------
@app.route("/")
def home():
    alerts = []
    vehicles = vehicle_df.to_dict(orient='records')
    all_data_points = []  # ✅ prevent Undefined error in template

    return render_template(
        "index.html",
        alerts=alerts,
        vehicles=vehicles,
        all_data_points=all_data_points
    )

# ---------- Email Alert Route ----------
@app.route("/send_alert_email", methods=["POST"])
def send_alert_email():
    data = request.json
    alert_message = data.get("message", "AI detected an alert.")
    try:
        msg = Message(
            'Urgent Alert from NaviLogix',
            sender=app.config['MAIL_USERNAME'],
            recipients=['recipient_email@example.com']
        )
        msg.body = alert_message
        mail.send(msg)
        return jsonify({"success": True, "message": "Alert email sent successfully!"})
    except Exception as e:
        return jsonify({"success": False, "message": f"Failed to send email: {str(e)}"}), 500

# ---------- Run App ----------
if __name__ == "__main__":
    app.run(debug=True)