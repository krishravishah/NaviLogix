from flask import Flask, render_template, request
from datetime import datetime, date
from math import ceil
import requests
import sqlite3
import warnings
import os
import time
import logging
import joblib

warnings.filterwarnings("ignore")

app = Flask(__name__)

TRACKING_API = 'https://103.249.96.104:8083/LPTMSAPI/api/LPInternAPI/GetTMSMapTrackingData'
VEHICLE_MASTER_API = 'https://103.249.96.104:8083/LPTMSAPI/api/LPInternAPI/TMSGetMAPMasterData'
DB_PATH = 'database/vehicles.db'
GOOGLE_API_KEY = 'AIzaSyAxwJOtg48aBuAuRaEGXIrZP2GfVyglOgY'

is_delay_model = joblib.load("ai/delay_is_delay_model.pkl")
delay_percentage_model = joblib.load("ai/delay_delay_percentage_model.pkl")

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')


def fetch_tracking_data(vehicle_no, max_retries=5, delay=3):
    payload = {"VehicleNo": vehicle_no}
    for attempt in range(1, max_retries + 1):
        try:
            logging.info(f"Attempt {attempt} to fetch tracking data for {vehicle_no}")
            response = requests.post(TRACKING_API, json=payload, verify=False, timeout=10)
            response.raise_for_status()
            return response.json()
        except requests.RequestException as e:
            logging.error(f"Error on attempt {attempt}: {e}")
            if attempt < max_retries:
                time.sleep(delay)
    return None


def fetch_vehicle_master_list():
    try:
        response = requests.get(VEHICLE_MASTER_API, json={}, verify=False, timeout=10)
        response.raise_for_status()
        data = response.json()
        if data and data.get('StatusID') == 0 and data.get('Data'):
            vehicles = data['Data'].get('Table', [])
            vehicle_numbers = [v['VehicleNo'] for v in vehicles if 'VehicleNo' in v]
            return vehicle_numbers
    except requests.RequestException as e:
        logging.error(f"Error fetching vehicle master list: {e}")
    return []


def save_to_tracking_data(trip_data, tracking_data):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    today_str = date.today().strftime('%Y-%m-%d')
    cursor.execute("DELETE FROM tracking_data WHERE date(date_time) != ?", (today_str,))

    for t in tracking_data:
        if not t.get('DtTime') or not t['DtTime'].startswith(today_str):
            continue

        cursor.execute('''
            SELECT COUNT(*) FROM tracking_data WHERE vehicle_no = ? AND date_time = ?
        ''', (t['VName'], t['DtTime']))
        exists = cursor.fetchone()[0]

        if exists == 0:
            cursor.execute('''
                INSERT INTO tracking_data (
                    vehicle_no, trip_id, trip_no, job_no, requested_date, company_name,
                    shipper_name, consignee_name, lr_no, lr_date, transport_mode, 
                    loading_location, unloading_location, shipment_no, tracking_sr_no,
                    date_time, lat, lng, speed, odometer, created_date
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                t['VName'],
                trip_data.get('TripId'),
                trip_data.get('TripNo'),
                trip_data.get('JobNo'),
                trip_data.get('RequestedDate'),
                trip_data.get('CompanyName'),
                trip_data.get('ShipperName'),
                trip_data.get('ConsigneeName'),
                trip_data.get('LRNo'),
                trip_data.get('LRDate'),
                trip_data.get('TransportMode'),
                trip_data.get('LoadingLocation'),
                trip_data.get('UnloadingLocation'),
                trip_data.get('ShipmentNo'),
                t['SrNo'],
                t['DtTime'],
                t['Lat'],
                t['Lngt'],
                t['Speed'],
                t['Odometer'],
                t.get('CreatedDate')
            ))

    conn.commit()
    conn.close()


def format_datetime_safe(dt_str):
    if not dt_str:
        return "N/A"
    try:
        dt_obj = datetime.strptime(dt_str.split('.')[0], '%Y-%m-%dT%H:%M:%S')
        return dt_obj.strftime('%d-%m-%Y at %I:%M:%S %p')
    except ValueError:
        try:
            dt_obj = datetime.strptime(dt_str, '%Y-%m-%d %H:%M:%S')
            return dt_obj.strftime('%d-%m-%Y at %I:%M:%S %p')
        except ValueError:
            try:
                dt_obj = datetime.strptime(dt_str, '%Y-%m-%d')
                return dt_obj.strftime('%d-%m-%Y')
            except ValueError:
                return dt_str


def get_result_points():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute('SELECT lat, lng, date_time FROM tracking_data ORDER BY date_time ASC')
    points = cursor.fetchall()
    conn.close()

    today_str = date.today().strftime('%Y-%m-%d')
    today_points = [(lat, lng, dt) for (lat, lng, dt) in points if dt and dt.startswith(today_str)]

    if not today_points:
        return []

    latest_point = max(today_points, key=lambda x: x[2])
    result_points = []

    for (lat, lng, dt) in today_points:
        formatted_time = format_datetime_safe(dt)
        icon = 'currentlocation.png' if (lat, lng, dt) == latest_point else 'pastlocation.png'
        result_points.append({
            'lat': lat,
            'lng': lng,
            'datetime': formatted_time,
            'icon': icon
        })

    return result_points


def get_latest_result():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute('''
        SELECT trip_no, job_no, requested_date, company_name, shipper_name, consignee_name,
               lr_no, lr_date, transport_mode, loading_location, unloading_location, shipment_no,
               speed, odometer, date_time, lat, lng
        FROM tracking_data
        ORDER BY date_time DESC LIMIT 1
    ''')
    latest = cursor.fetchone()
    conn.close()
    return latest


def clear_tracking_data():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute('DELETE FROM tracking_data')
    cursor.execute("DELETE FROM sqlite_sequence WHERE name='tracking_data'")
    conn.commit()
    conn.close()


def geocode_location(location):
    geocode_url = f"https://maps.googleapis.com/maps/api/geocode/json?address={location}&key={GOOGLE_API_KEY}"
    response = requests.get(geocode_url)
    data = response.json()
    if data["status"] == "OK":
        loc = data["results"][0]["geometry"]["location"]
        return loc["lat"], loc["lng"]
    return None, None


def get_eta_distance(origin, destination):

    url = f"https://maps.googleapis.com/maps/api/distancematrix/json?origins={origin}&destinations={destination}&key={GOOGLE_API_KEY}"
    response = requests.get(url)
    data = response.json()
    if data["status"] == "OK":
        try:
            row = data["rows"][0]["elements"][0]
            if row["status"] == "OK":
                duration = ceil(row["duration"]["value"] / 60)
                distance = round(row["distance"]["value"] / 1000, 2)
                return duration, distance
        except:
            pass

    orig_lat, orig_lng = geocode_location(origin)
    dest_lat, dest_lng = geocode_location(destination)
    if orig_lat and dest_lat:
        url = f"https://maps.googleapis.com/maps/api/distancematrix/json?origins={orig_lat},{orig_lng}&destinations={dest_lat},{dest_lng}&key={GOOGLE_API_KEY}"
        response = requests.get(url)
        data = response.json()
        if data["status"] == "OK":
            try:
                row = data["rows"][0]["elements"][0]
                if row["status"] == "OK":
                    duration = row["duration"]["value"] // 60
                    distance = round(row["distance"]["value"] / 1000, 2)
                    return duration, distance
            except:
                pass

    return None, None

@app.route('/', methods=['GET', 'POST'])
def home():
    vehicle_no = None
    error_message = None
    vehicle_data = None
    all_data_points = []

    if request.method == 'GET' and 'Vnumber' in request.args:
        vehicle_no = request.args.get('Vnumber')
        logging.info(f"Auto-tracking vehicle number from URL: {vehicle_no}")
        clear_tracking_data()
        api_data = fetch_tracking_data(vehicle_no)

        if api_data and api_data.get('StatusID') == 0 and api_data.get('Data'):
            trip_data_list = api_data['Data'].get('Table', [])
            tracking_data_list = api_data['Data'].get('Table1', [])

            if trip_data_list and tracking_data_list:
                trip_data = trip_data_list[0]
                save_to_tracking_data(trip_data, tracking_data_list)
                all_data_points = get_result_points()
                latest = get_latest_result()

                if latest:
                    speed = latest[12]
                    status = 'In Transit' if speed > 0 else 'Idle'
                    status_class = 'in-transit' if speed > 0 else 'idle'

                    loading_display = latest[9]
                    unloading_display = latest[10]

                    unloading_ai = trip_data.get('UnloadingLocation')

                    if latest[15] and latest[16]:
                        origin = f"{latest[15]},{latest[16]}"
                    else:
                        origin = trip_data.get('LoadingLocation')

                    eta, dist = get_eta_distance(origin, unloading_ai)

                    if eta is not None and dist is not None:
                        print("📦 Model Input — Distance:", dist, "ETA:", eta)
                        proba = is_delay_model.predict_proba([[dist, eta]])[0][1]
                        print("📊 Is_Delay Probability Score:", round(proba * 100, 2), "%")
                        if proba is not None:
                            if proba >= 0.6:
                                confidence_label = "High"
                                confidence_class = "high"
                            elif proba >= 0.3:
                                confidence_label = "Medium"
                                confidence_class = "medium"
                            else:
                                confidence_label = "Low"
                                confidence_class = "low"
                        else:
                            confidence_label = "Unknown"
                            confidence_class = "unknown"
                        prob = delay_percentage_model.predict([[dist, eta]])[0]
                        print("📊 Delay_Percentage Score:", round(prob, 2), "%")
                        eta = ceil(eta) if eta is not None else None
                        if eta is not None:
                            eta_hours = eta // 60
                            eta_minutes = eta % 60
                            if eta_hours > 0 and eta_minutes > 0:
                                eta_str = f"{eta_hours} hr {eta_minutes} min"
                            elif eta_hours > 0:
                                eta_str = f"{eta_hours} hr"
                            else:
                                eta_str = f"{eta_minutes} min"
                        else:
                            eta_str = "N/A"
                        delay_minutes = ceil((prob / 100) * eta) if eta is not None and prob is not None else None
                        if delay_minutes is not None:
                            if delay_minutes <= 10:
                                schedule_adherence_class = 'on-time'
                                schedule_adherence_label = 'On Time'
                            elif delay_minutes <= 30:
                                schedule_adherence_class = 'minor'
                                schedule_adherence_label = 'Minor Delay'
                            elif delay_minutes <= 60:
                                schedule_adherence_class = 'moderate'
                                schedule_adherence_label = 'Moderate Delay'
                            else:
                                schedule_adherence_class = 'severe'
                                schedule_adherence_label = 'Severe Delay'
                        else:
                            schedule_adherence_class = 'unknown'
                            schedule_adherence_label = 'Unknown'
                        adjusted_eta_time = eta + delay_minutes if eta is not None and delay_minutes is not None else None
                        if adjusted_eta_time is not None:
                            hours = adjusted_eta_time // 60
                            minutes = adjusted_eta_time % 60
                            if hours > 0 and minutes > 0:
                                adjusted_eta_str = f"{hours} hr {minutes} min"
                            elif hours > 0:
                                adjusted_eta_str = f"{hours} hr"
                            else:
                                adjusted_eta_str = f"{minutes} min"
                        else:
                            adjusted_eta_str = "N/A"
                    else:
                        print(f"⚠️ Could not get valid ETA/Distance for: {origin} ➡️ {unloading_ai}")
                        eta = None
                        dist = None
                        prob = None
                        proba = None
                        delay_minutes = None

                    vehicle_data = {
                        'trip_no': latest[0],
                        'job_no': latest[1],
                        'requested_date': format_datetime_safe(latest[2]),
                        'company_name': latest[3],
                        'shipper_name': latest[4],
                        'consignee_name': latest[5],
                        'lr_no': latest[6],
                        'lr_date': format_datetime_safe(latest[7]),
                        'transport_mode': latest[8],
                        'loading_location': loading_display,
                        'unloading_location': unloading_display,
                        'shipment_no': latest[11],
                        'speed': speed,
                        'odometer': round(latest[13]) if latest[13] is not None else "N/A",
                        'last_update': format_datetime_safe(latest[14]),
                        'lat': latest[15],
                        'lng': latest[16],
                        'status': status,
                        'status_class': status_class,
                        'vehicle_eta': eta_str,
                        'distance': f"{dist} km" if dist is not None else "N/A",
                        'schedule_adherence_class': schedule_adherence_class,
                        'schedule_adherence_label': schedule_adherence_label,
                        'confidence_label': confidence_label,
                        'confidence_class': confidence_class,
                        'delay_classification_percentage': f"{round(proba * 100, 2)}%" if proba is not None else "N/A",
                        'delay_regression_percentage': (
                            f"{round(prob, 2)}%" if prob is not None and prob > 1 else
                            f"{round(prob * 100, 2)}%" if prob is not None else "N/A"
                        ),
                        'delay_minutes': (
                            f"{delay_minutes // 60} hr {delay_minutes % 60} min" if delay_minutes and delay_minutes >= 60 else
                            f"{delay_minutes} min" if delay_minutes is not None else "N/A"
                        ),
                        'adjusted_eta': adjusted_eta_str,
                    }
                else:
                    vehicle_data = None
                    all_data_points = []
                    error_message = f"No tracking data found for vehicle number: {vehicle_no}"
            else:
                vehicle_data = None
                all_data_points = []
                error_message = f"No tracking data found for vehicle number: {vehicle_no}"
        else:
            vehicle_data = None
            all_data_points = []

    elif request.method == 'POST':
        vehicle_no = request.form['vehicle_no']
        logging.info(f"Tracking vehicle number: {vehicle_no}")
        clear_tracking_data()
        api_data = fetch_tracking_data(vehicle_no)

        if api_data and api_data.get('StatusID') == 0 and api_data.get('Data'):
            trip_data_list = api_data['Data'].get('Table', [])
            tracking_data_list = api_data['Data'].get('Table1', [])

            if trip_data_list and tracking_data_list:
                trip_data = trip_data_list[0]
                save_to_tracking_data(trip_data, tracking_data_list)
                all_data_points = get_result_points()
                latest = get_latest_result()

                if latest:
                    speed = latest[12]
                    status = 'In Transit' if speed > 0 else 'Idle'
                    status_class = 'in-transit' if speed > 0 else 'idle'

                    loading_display = latest[9]
                    unloading_display = latest[10]
                    unloading_ai = trip_data.get('UnloadingLocation')

                    if latest[15] and latest[16]:
                        origin = f"{latest[15]},{latest[16]}"
                    else:
                        origin = trip_data.get('LoadingLocation')

                    eta, dist = get_eta_distance(origin, unloading_ai)

                    if eta is not None and dist is not None:
                        print("📦 Model Input — Distance:", dist, "ETA:", eta)
                        proba = is_delay_model.predict_proba([[dist, eta]])[0][1]
                        print("📊 Is_Delay Probability Score:", round(proba * 100, 2), "%")

                        if proba is not None:
                            if proba >= 0.6:
                                confidence_label = "High"
                                confidence_class = "high"
                            elif proba >= 0.3:
                                confidence_label = "Medium"
                                confidence_class = "medium"
                            else:
                                confidence_label = "Low"
                                confidence_class = "low"
                        else:
                            confidence_label = "Unknown"
                            confidence_class = "unknown"

                        prob = delay_percentage_model.predict([[dist, eta]])[0]
                        print("📊 Delay_Percentage Score:", round(prob, 2), "%")

                        eta = ceil(eta)
                        eta_hours = eta // 60
                        eta_minutes = eta % 60
                        if eta_hours > 0 and eta_minutes > 0:
                            eta_str = f"{eta_hours} hr {eta_minutes} min"
                        elif eta_hours > 0:
                            eta_str = f"{eta_hours} hr"
                        else:
                            eta_str = f"{eta_minutes} min"

                        delay_minutes = ceil((prob / 100) * eta) if prob is not None else None

                        if delay_minutes is not None:
                            if delay_minutes <= 10:
                                schedule_adherence_class = 'on-time'
                                schedule_adherence_label = 'On Time'
                            elif delay_minutes <= 30:
                                schedule_adherence_class = 'minor'
                                schedule_adherence_label = 'Minor Delay'
                            elif delay_minutes <= 60:
                                schedule_adherence_class = 'moderate'
                                schedule_adherence_label = 'Moderate Delay'
                            else:
                                schedule_adherence_class = 'severe'
                                schedule_adherence_label = 'Severe Delay'
                        else:
                            schedule_adherence_class = 'unknown'
                            schedule_adherence_label = 'Unknown'

                        adjusted_eta_time = eta + delay_minutes if delay_minutes is not None else None
                        if adjusted_eta_time is not None:
                            hours = adjusted_eta_time // 60
                            minutes = adjusted_eta_time % 60
                            if hours > 0 and minutes > 0:
                                adjusted_eta_str = f"{hours} hr {minutes} min"
                            elif hours > 0:
                                adjusted_eta_str = f"{hours} hr"
                            else:
                                adjusted_eta_str = f"{minutes} min"
                        else:
                            adjusted_eta_str = "N/A"
                    else:
                        print(f"⚠️ Could not get valid ETA/Distance for: {origin} ➡️ {unloading_ai}")
                        eta_str = "N/A"
                        adjusted_eta_str = "N/A"
                        dist = None
                        proba = None
                        prob = None
                        delay_minutes = None
                        confidence_label = "Unknown"
                        confidence_class = "unknown"
                        schedule_adherence_class = 'unknown'
                        schedule_adherence_label = 'Unknown'

                    vehicle_data = {
                        'trip_no': latest[0],
                        'job_no': latest[1],
                        'requested_date': format_datetime_safe(latest[2]),
                        'company_name': latest[3],
                        'shipper_name': latest[4],
                        'consignee_name': latest[5],
                        'lr_no': latest[6],
                        'lr_date': format_datetime_safe(latest[7]),
                        'transport_mode': latest[8],
                        'loading_location': loading_display,
                        'unloading_location': unloading_display,
                        'shipment_no': latest[11],
                        'speed': speed,
                        'odometer': round(latest[13]) if latest[13] is not None else "N/A",
                        'last_update': format_datetime_safe(latest[14]),
                        'lat': latest[15],
                        'lng': latest[16],
                        'status': status,
                        'status_class': status_class,
                        'vehicle_eta': eta_str,
                        'distance': f"{dist} km" if dist is not None else "N/A",
                        'schedule_adherence_class': schedule_adherence_class,
                        'schedule_adherence_label': schedule_adherence_label,
                        'confidence_label': confidence_label,
                        'confidence_class': confidence_class,
                        'delay_classification_percentage': f"{round(proba * 100, 2)}%" if proba is not None else "N/A",
                        'delay_regression_percentage': f"{round(prob, 2)}%" if prob is not None else "N/A",
                        'delay_minutes': f"{delay_minutes} min" if delay_minutes is not None else "N/A",
                        'adjusted_eta': adjusted_eta_str,
                    }
                else:
                    vehicle_data = None
                    all_data_points = []
                    error_message = f"No tracking data found for vehicle number: {vehicle_no}"
            else:
                vehicle_data = None
                all_data_points = []
                error_message = f"No tracking data found for vehicle number: {vehicle_no}"
        else:
            vehicle_data = None
            all_data_points = []

    else:
        logging.info("GET request — clearing tracking data table.")
        clear_tracking_data()
        vehicle_numbers = fetch_vehicle_master_list()
        for vehicle_no in vehicle_numbers:
            api_data = fetch_tracking_data(vehicle_no)
            if api_data and api_data.get('StatusID') == 0 and api_data.get('Data'):
                trip_data_list = api_data['Data'].get('Table', [])
                tracking_data_list = api_data['Data'].get('Table1', [])
                if trip_data_list and tracking_data_list:
                    trip_data = trip_data_list[0]
                    save_to_tracking_data(trip_data, tracking_data_list)

        vehicle_data = None
        all_data_points = []

    return render_template('index.html', vehicle_data=vehicle_data, all_data_points=all_data_points, vehicle_no=vehicle_no, error_message=error_message)


if __name__ == '__main__':
    os.makedirs("database", exist_ok=True)
    clear_tracking_data()
    app.run(host="0.0.0.0", port=5000, debug=True)