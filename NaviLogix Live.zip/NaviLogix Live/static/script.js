let map;
let currentInfoWindow = null;
let unloadingLocationLatLng = null;
let loadingLocationLatLng = null;
let hasPlotted = false;
let directionsPolylineBounds = null;

function initMap() {
    const defaultLatLng = { lat: 19.0760, lng: 72.8777 };
    map = new google.maps.Map(document.getElementById("map"), {
        zoom: 8,
        center: defaultLatLng,
    });

    if (points && points.length > 0) {
        plotMarkers(points);
    }

    if (loadingLocationName) {
        geocodeAddress(loadingLocationName, '/static/loadinglocation.png', "Loading Location", (latLng) => {
            loadingLocationLatLng = latLng;
            if (points && points.length > 0) {
                drawPastTrail(points);
                tryZoomToRoute(points);
            }
        });
    }

    if (unloadingLocationName) {
        geocodeAddress(unloadingLocationName, '/static/unloadinglocation.png', "Unloading Location", (latLng) => {
            unloadingLocationLatLng = latLng;
            if (points && points.length > 0) {
                drawBestRoute(points[points.length - 1], unloadingLocationLatLng, (polylineBounds) => {
                    directionsPolylineBounds = polylineBounds;
                    tryZoomToRoute(points);
                });
            }
        });
    }

    map.addListener("click", () => {
        if (currentInfoWindow) {
            currentInfoWindow.close();
            currentInfoWindow = null;
        }
    });
}

function tryZoomToRoute(points) {
    if (
        loadingLocationLatLng &&
        unloadingLocationLatLng &&
        points.length > 0 &&
        directionsPolylineBounds &&
        !hasPlotted
    ) {
        zoomToRoute(points);
    }
}

function plotMarkers(points) {
    const placedPositions = new Set();

    points.forEach(p => {
        const posKey = `${p.lat},${p.lng}`;
        const iconUrl = '/static/' + p.icon;
        const position = { lat: p.lat, lng: p.lng };

        if (p.icon === 'pastlocation.png' && placedPositions.has(posKey)) {
            return;
        }

        const marker = new google.maps.Marker({
            position: position,
            map: map,
            icon: {
                url: iconUrl,
                scaledSize: new google.maps.Size(24, 24)
            }
        });

        const infoWindow = new google.maps.InfoWindow({
            content: `<b>Logged:</b> ${p.datetime}`
        });

        marker.addListener("click", () => {
            if (currentInfoWindow) {
                currentInfoWindow.close();
            }
            infoWindow.open(map, marker);
            currentInfoWindow = infoWindow;
        });

        placedPositions.add(posKey);
    });
}

function geocodeAddress(address, iconUrl, title, callback = null) {
    const geocoder = new google.maps.Geocoder();

    geocoder.geocode({ address: address }, (results, status) => {
        if (status === "OK") {
            const location = results[0].geometry.location;

            const marker = new google.maps.Marker({
                map: map,
                position: location,
                icon: {
                    url: iconUrl,
                    scaledSize: new google.maps.Size(32, 32)
                },
                title: title
            });

            const infoWindow = new google.maps.InfoWindow({
                content: `<b>${title}:</b><br>${address}`
            });

            marker.addListener("click", () => {
                if (currentInfoWindow) {
                    currentInfoWindow.close();
                }
                infoWindow.open(map, marker);
                currentInfoWindow = infoWindow;
            });

            if (callback) callback(location);
        } else {
            console.error("Geocode failed for " + address + ": " + status);
        }
    });
}

function drawBestRoute(originPoint, destinationLatLng, onComplete = null) {
    const directionsService = new google.maps.DirectionsService();
    const directionsRenderer = new google.maps.DirectionsRenderer({
        map: map,
        suppressMarkers: true
    });

    const origin = { lat: originPoint.lat, lng: originPoint.lng };
    const destination = destinationLatLng;

    const request = {
        origin: origin,
        destination: destination,
        travelMode: google.maps.TravelMode.DRIVING
    };

    directionsService.route(request, (result, status) => {
        if (status === 'OK') {
            directionsRenderer.setDirections(result);

            const leg = result.routes[0].legs[0];
            const remainingDistance = leg.distance.text;
            const eta = leg.duration.text;

            const distanceElem = document.getElementById("remainingDistance");
            const etaElem = document.getElementById("eta");

            if (distanceElem) {
                distanceElem.innerText = remainingDistance
                    .replace("kms", "km")
                    .replace("kilometers", "km");
            }

            if (etaElem) {
                etaElem.innerText = eta
                    .replace("mins", "min")
                    .replace("minutes", "min")
                    .replace("hours", "hr")
                    .replace("hour", "hr");
}

            const polylineBounds = new google.maps.LatLngBounds();
            result.routes[0].overview_path.forEach(p => polylineBounds.extend(p));

            if (onComplete) onComplete(polylineBounds);
        } else {
            console.error("Directions request failed: " + status);
        }
    });
}

function drawPastTrail(points) {
    if (!loadingLocationLatLng || points.length < 1) return;

    const pathCoords = [
        { lat: loadingLocationLatLng.lat(), lng: loadingLocationLatLng.lng() },
        ...points.map(p => ({ lat: p.lat, lng: p.lng }))
    ];

    const polyline = new google.maps.Polyline({
        path: pathCoords,
        geodesic: true,
        strokeColor: '#888',
        strokeOpacity: 0,
        strokeWeight: 2,
        icons: [{
            icon: {
                path: 'M 0,-1 0,1',
                strokeOpacity: 1,
                scale: 4
            },
            offset: '0',
            repeat: '20px'
        }]
    });

    polyline.setMap(map);
}

function zoomToRoute(points) {
    if (!loadingLocationLatLng || !unloadingLocationLatLng || points.length === 0 || hasPlotted) return;

    const bounds = new google.maps.LatLngBounds();
    bounds.extend(loadingLocationLatLng);
    bounds.extend(unloadingLocationLatLng);
    points.forEach(p => bounds.extend({ lat: p.lat, lng: p.lng }));
    bounds.union(directionsPolylineBounds);

    map.fitBounds(bounds);

    setTimeout(() => {
        const latest = points[points.length - 1];
        const target = new google.maps.LatLng(latest.lat, latest.lng);
        const currentZoom = map.getZoom();
        const targetZoom = 16;

        console.log("📍 Zooming to latest point:", target.toString());
        console.log("🔍 Current Zoom:", currentZoom);
        console.log("🎯 Target Zoom:", targetZoom);

        smoothZoomToPoint(target, currentZoom, targetZoom);

        hasPlotted = true;
    }, 2000);
}

function smoothZoomToPoint(targetLatLng, currentZoom, targetZoom) {
    let zoom = currentZoom;

    const step = zoom < targetZoom ? 1 : -1;

    function zoomStep() {
        map.setZoom(zoom);
        map.panTo(targetLatLng);

        if ((step > 0 && zoom >= targetZoom) || (step < 0 && zoom <= targetZoom)) {
            return;
        }

        zoom += step;
        setTimeout(zoomStep, 200);
    }

    zoomStep();
}

if (window.location.search.includes("Vnumber")) {
    const reloadCount = sessionStorage.getItem("reloadCount") || 0;

    if (reloadCount >= 1) {
        if (window.history.replaceState) {
            window.history.replaceState(null, null, window.location.pathname);
        }
    }
    sessionStorage.setItem("reloadCount", Number(reloadCount) + 1);
} else {
    sessionStorage.setItem("reloadCount", 0);
}