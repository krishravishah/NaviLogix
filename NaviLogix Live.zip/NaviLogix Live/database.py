import sqlite3
import os

os.makedirs("database", exist_ok=True)
conn = sqlite3.connect('database/vehicles.db')
cursor = conn.cursor()

cursor.execute('''
CREATE TABLE IF NOT EXISTS tracking_data (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    vehicle_no TEXT,
    trip_id TEXT,
    trip_no TEXT,
    job_no TEXT,
    requested_date TEXT,
    company_name TEXT,
    shipper_name TEXT,
    consignee_name TEXT,
    lr_no TEXT,
    lr_date TEXT,
    transport_mode TEXT,
    loading_location TEXT,
    unloading_location TEXT,
    shipment_no TEXT,
    tracking_sr_no TEXT,
    date_time TEXT,
    lat REAL,
    lng REAL,
    speed REAL,
    odometer REAL,
    created_date TEXT
);
''')

conn.commit()
conn.close()

print("Database and tables ready.")