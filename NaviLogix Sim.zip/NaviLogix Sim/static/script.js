let map;
let directionsService;
let directionsRenderer;
let vehicleMarker = null;
let moveInterval = null;

window.initMap = function () {
    map = new google.maps.Map(document.getElementById("map"), {
        center: { lat: 20.5937, lng: 78.9629 },
        zoom: 5,
    });

    directionsService = new google.maps.DirectionsService();
    directionsRenderer = new google.maps.DirectionsRenderer({
        map: map,
        suppressMarkers: true
    });

    const routeBtn = document.getElementById("routeBtn");
    if (routeBtn) {
        routeBtn.addEventListener("click", trackVehicle);
    }
};

function formatDuration(seconds) {
    const days = Math.floor(seconds / (3600 * 24));
    const hours = Math.floor((seconds % (3600 * 24)) / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);

    let result = "";
    if (days > 0) result += `${days}d `;
    if (hours > 0) result += `${hours}h `;
    if (minutes > 0) result += `${minutes}m`;
    if (result === "") result = "Less than a minute";
    return result.trim();
}

function getUltraSmoothPath(path, segmentsPerStep = 100) {
    const smoothPath = [];
    for (let i = 0; i < path.length - 1; i++) {
        const start = path[i];
        const end = path[i + 1];
        for (let j = 0; j < segmentsPerStep; j++) {
            const fraction = j / segmentsPerStep;
            const interpolatedPoint = google.maps.geometry.spherical.interpolate(start, end, fraction);
            smoothPath.push(interpolatedPoint);
        }
    }
    smoothPath.push(path[path.length - 1]);
    return smoothPath;
}

function getDistanceBetweenPoints(points, startIdx, endIdx) {
    let distance = 0;
    for (let i = startIdx; i < endIdx; i++) {
        distance += google.maps.geometry.spherical.computeDistanceBetween(points[i], points[i + 1]);
    }
    return distance;
}

function trackVehicle() {
    const vehicleSelect = document.getElementById("vehicleSelect");

    if (!vehicleSelect.value) {
        Swal.fire({
            icon: 'info',
            title: 'Oops...',
            text: 'Please select a vehicle.',
            background: '#1e1e2f',
            color: '#f0f0f0'
        });
        return;
    }

    const vehicle = JSON.parse(vehicleSelect.value);
    const factory = { lat: vehicle.warehouse_lat, lng: vehicle.warehouse_lng };
    const port = { lat: vehicle.port_lat, lng: vehicle.port_lng };

    const request = {
        origin: factory,
        destination: port,
        travelMode: google.maps.TravelMode.DRIVING
    };

    directionsService.route(request, (result, status) => {
        if (status === google.maps.DirectionsStatus.OK) {
            directionsRenderer.setDirections(result);

            const routeLeg = result.routes[0].legs[0];
            const totalDistance = routeLeg.distance.text;
            const totalDurationSec = routeLeg.duration.value;

            let fullPath = [];
            result.routes[0].legs[0].steps.forEach(step => {
                fullPath = fullPath.concat(step.path);
            });
            const smoothPath = getUltraSmoothPath(fullPath, 50);

            const startIndex = Math.floor(Math.random() * smoothPath.length);
            let step = startIndex;
            const stepIncrement = 0.5;

            const totalDistanceMeters = google.maps.geometry.spherical.computeLength(smoothPath);
            const averageSpeedMps = totalDistanceMeters / totalDurationSec;

            if (vehicleMarker) vehicleMarker.setMap(null);
            if (moveInterval) clearInterval(moveInterval);

            vehicleMarker = new google.maps.Marker({
                position: smoothPath[Math.floor(step)],
                map: map,
                icon: {
                    url: vehicleIconUrl,
                    scaledSize: new google.maps.Size(48, 48),
                    anchor: new google.maps.Point(24, 24)
                }
            });

            const warehouseMarker = new google.maps.Marker({
                position: fullPath[0],
                map: map,
                icon: {
                    url: warehouseIconUrl,
                    scaledSize: new google.maps.Size(48, 48),
                    anchor: new google.maps.Point(24, 24)
                }
            });

            const portMarker = new google.maps.Marker({
                position: fullPath[fullPath.length - 1],
                map: map,
                icon: {
                    url: portIconUrl,
                    scaledSize: new google.maps.Size(48, 48),
                    anchor: new google.maps.Point(24, 24)
                }
            });

            const totalSteps = smoothPath.length - startIndex;
            const stepDurationMs = (totalDurationSec * 1000) / totalSteps;

            document.getElementById("routeInfo").innerHTML = `
                <div style="padding:10px; background:#003366; color:white; margin-top:10px; border-radius:8px;">
                    <div class="label-item"><strong>Vehicle Number:</strong> ${vehicle.vehicle_id}</div>
                    <div class="label-item"><strong>Origin:</strong> ${routeLeg.start_address}</div>
                    <div class="label-item"><strong>Destination:</strong> ${routeLeg.end_address}</div>
                    <div class="label-item"><strong>Total Distance:</strong> ${totalDistance}</div>
                    <div class="label-item"><strong>Estimated Journey Duration:</strong> ${formatDuration(totalDurationSec)}</div>
                    <div id="liveEta" style="display:block; margin-top:8px;"></div>
                </div>
            `;

            function moveVehicle() {
                if (step >= smoothPath.length - 1) {
                    document.getElementById("liveEta").innerHTML = `<strong>Current ETA to Destination:</strong> Arrived!`;
                    Swal.fire({
                        icon: 'success',
                        title: 'Arrived!',
                        text: `${vehicle.vehicle_id} has reached its destination.`,
                        background: '#1e1e2f',
                        color: '#f0f0f0'
                    });
                    return;
                }

                const floorStep = Math.floor(step);
                const ceilStep = Math.min(floorStep + 1, smoothPath.length - 1);
                const fraction = step - floorStep;

                const pos = google.maps.geometry.spherical.interpolate(smoothPath[floorStep], smoothPath[ceilStep], fraction);
                vehicleMarker.setPosition(pos);

                const remainingDistance =
                    google.maps.geometry.spherical.computeDistanceBetween(pos, smoothPath[ceilStep]) +
                    getDistanceBetweenPoints(smoothPath, ceilStep, smoothPath.length - 1);

                const remainingTimeSec = remainingDistance / averageSpeedMps;

                const days = Math.floor(remainingTimeSec / 86400);
                const hours = Math.floor((remainingTimeSec % 86400) / 3600);
                const minutes = Math.floor((remainingTimeSec % 3600) / 60);

                let etaString = '';
                if (days > 0) etaString += `${days}d `;
                if (hours > 0) etaString += `${hours}h `;
                etaString += `${minutes}m`;

                document.getElementById("liveEta").innerHTML = `<strong>Remaining Travel Time:</strong> ${etaString}`;

                step += stepIncrement;
                setTimeout(moveVehicle, stepDurationMs * stepIncrement);
            }

            moveVehicle();

        } else {
            Swal.fire({
                icon: 'error',
                title: 'Route Error',
                text: 'Could not find a route: ' + status,
                background: '#1e1e2f',
                color: '#f0f0f0'
            });
            document.getElementById("routeInfo").innerHTML = '';
        }
    });
}